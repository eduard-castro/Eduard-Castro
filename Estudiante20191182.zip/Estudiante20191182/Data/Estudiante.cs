using System.ComponentModel.DataAnnotations;
namespace Estudiante20191182.Data.Models;
public class estudiante 
{
[Key]
    public int estudianteID {get;set;}
    public string? Nombre {get;set;}
   public string? Apellido {get;set;}
   public string? FechaNacimiento {get;set;}
public string? Matricula {get;set;}
public string? Carrera {get;set;}
}
