using Estudiante20191182.Data.Models;
using Microsoft.EntityFrameworkCore;

namespace Estudiante20191182.Data.Context;

public class Estudiante20191182DbContext:DbContext,IEstudiante20191182DbContext
{
   public Estudiante20191182DbContext (DbContextOptions options):base(options)
    {
        
    }
    public virtual DbSet < estudiante> EstudianteID {get; set;} = null!;


}
public interface IEstudiante20191182DbContext {public  DbSet < estudiante> EstudianteID {get; set;} }


